var user = navigator.userAgent;
var version=navigator.appVersion
document.write("Browser: <h2>")
document.write(user)
document.write("</h2>")

document.write("Version:<h2>"+version+"</h2>")